# Dicionário de dados

Codificação: UTF-8; separador: vírgula; decimal: ponto. Célula vazia = dado não disponível.

## data/pam_milho_norte_mt_2000_2020.csv
Uma linha por município e ano (55 × 21 = 1.155 linhas). Fonte: IBGE/PAM, SIDRA tabela 5457, produto "milho (em grão)" (1ª + 2ª safras).

| Variável | Tipo | Unidade | Descrição |
|---|---|---|---|
| cod_ibge | texto (7 dígitos) | — | Código IBGE do município |
| municipio | texto | — | Nome do município |
| microrregiao | texto | — | Microrregião geográfica do IBGE |
| ano | inteiro | — | Ano de referência da PAM |
| area_plantada_ha | inteiro | ha | Área plantada ou destinada à colheita (SIDRA var. 8331) |
| area_colhida_ha | inteiro | ha | Área colhida (SIDRA var. 216) |
| producao_t | inteiro | t | Quantidade produzida (SIDRA var. 214) |

Variáveis derivadas usadas no artigo: produtividade = producao_t / area_colhida_ha × 1000 (kg ha⁻¹);
aproveitamento = area_colhida_ha / area_plantada_ha.

## data/municipios_norte_mt.csv
| Variável | Tipo | Unidade | Descrição |
|---|---|---|---|
| cod_ibge | texto | — | Código IBGE do município |
| municipio | texto | — | Nome do município |
| cod_microrregiao | texto | — | Código IBGE da microrregião (51001–51008) |
| microrregiao | texto | — | Nome da microrregião |
| lon_centroide, lat_centroide | decimal | graus (SIRGAS 2000) | Centroide geométrico do polígono municipal, usado na matriz de vizinhança do I de Moran |

## data/pam_milho_mesorregioes_mt_2000_2020.csv
| Variável | Descrição |
|---|---|
| cod_mesorregiao, mesorregiao | Código e nome da mesorregião de Mato Grosso (5101 a 5105) |
| ano | Ano |
| area_colhida_ha | Área colhida (ha) |
| producao_t | Produção (t) |

## data/pam_milho_mato_grosso_2000_2020.csv
Totais estaduais por ano: area_plantada_ha, area_colhida_ha, producao_t.

## data/pam839_milho_safras_norte_mt_2003_2020.csv
Mesorregião Norte Mato-grossense, SIDRA tabela 839 (série inicia em 2003).

| Variável | Descrição |
|---|---|
| producao_1a_safra_t | Produção de milho de 1ª safra (t) |
| producao_2a_safra_t | Produção de milho de 2ª safra (t) |
| producao_total_t | Soma das duas safras (t) |
| participacao_2a_safra | Fração da produção na 2ª safra (0–1) |

## data/parametros_estande_circuito_tecnologico_2017.csv
Parâmetros de plantabilidade de Borghi *et al.* (2018), usados nas Equações 2 e 3 do artigo.

## data/parametros_monte_carlo.csv
Distribuições e valores do cenário central da simulação (Tabela 2 do artigo).
d = n_f/(E + n_f); f_m = n_m/E; L = S·d + p_m·f_m; ΔP = P_obs·L/(1 − L); A_eq = ΔP/Ȳ.

## results/ (gerados pelos scripts)
| Arquivo | Conteúdo |
|---|---|
| serie_regional_norte_mt.csv | Série anual da mesorregião: áreas, produção, produtividade, aproveitamento e participação em MT |
| municipios_media_2016_2020_area_min_5000ha.csv | Médias 2016–2020 dos 39 municípios com área colhida média ≥ 5.000 ha, com a lacuna até o P90 |
| tabela5_monte_carlo.csv | Percentis 5, 50 e 95 e cenário central da perda (Tabela 5) |
| amostra_monte_carlo_10000.csv | Primeiras 10.000 iterações da simulação (d, S, p_m, L) |
