# Rendimento escondido no estande — conjunto de dados e códigos

Dados e scripts em Python que reproduzem as análises do artigo
**"Rendimento escondido no estande: falhas de semeadura no milho segunda safra do norte mato-grossense"**.

DOI deste depósito: `10.5281/zenodo.XXXXXXX` *(preencher após a publicação no Zenodo)*

## Conteúdo

```
data/
  pam_milho_norte_mt_2000_2020.csv           Série municipal (55 municípios × 21 anos = 1.155 linhas)
  municipios_norte_mt.csv                    Códigos IBGE, microrregião e centroides dos 55 municípios
  pam_milho_mesorregioes_mt_2000_2020.csv    Área colhida e produção das 5 mesorregiões de MT
  pam_milho_mato_grosso_2000_2020.csv        Totais estaduais (participação regional)
  pam839_milho_safras_norte_mt_2003_2020.csv Produção de 1ª e 2ª safra na mesorregião (tabela 839)
  parametros_estande_circuito_tecnologico_2017.csv  Parâmetros de plantabilidade (Borghi et al., 2018)
  parametros_monte_carlo.csv                 Distribuições da simulação (Tabela 2 do artigo)
scripts/
  01_serie_lacuna_moran.py                   Série regional, Mann-Kendall, Sen, lacuna (P90) e I de Moran
  02_monte_carlo_perda_estande.py            Cenário central, Monte Carlo e sensibilidade (Spearman)
results/                                     Saídas geradas pelos scripts
dicionario_de_dados.md                       Descrição de todas as variáveis
conjunto_de_dados_falhas_estande_milho.xlsx  Todas as tabelas de data/ em uma planilha (uma aba por arquivo)
```

## Como reproduzir

```bash
pip install -r requirements.txt
python scripts/01_serie_lacuna_moran.py
python scripts/02_monte_carlo_perda_estande.py
```

Rode o script 01 antes do 02 (o 02 usa a lacuna municipal calculada pelo 01).
Testado com Python 3.13, NumPy 2.5, pandas 3.0 e SciPy 1.18.

## Fontes dos dados

| Arquivo | Fonte | Consulta |
|---|---|---|
| `pam_milho_*` | IBGE, Produção Agrícola Municipal, SIDRA tabela 5457 (milho em grão, código 40122) — https://sidra.ibge.gov.br/tabela/5457 | out. 2026 |
| `pam839_*` | IBGE, Produção Agrícola Municipal, SIDRA tabela 839 (milho 1ª e 2ª safras) — https://sidra.ibge.gov.br/tabela/839 | out. 2026 |
| `municipios_norte_mt.csv` | Divisão territorial do IBGE (mesorregião 5101 e microrregiões 51001–51008, via SIDRA); centroides calculados a partir da malha municipal do IBGE disponibilizada em GeoJSON por *geodata-br* (https://github.com/tbrugz/geodata-br) | out. 2026 |
| `parametros_estande_*` | Borghi, E. *et al.* (2018), Circuito Tecnológico – Etapa Milho 2017 (Embrapa/Aprosoja-MT); CNA (2026) para o Imea em Campo | — |

### Controle de qualidade

- Em todos os 21 anos, a soma dos 55 municípios coincide exatamente com o total da mesorregião Norte Mato-grossense na tabela 5457.
- Em todos os anos, a soma das 5 mesorregiões coincide com o total estadual.
- O município de **Boa Esperança do Norte** (5101837), criado em 2023, não tem dados no período e foi excluído.

### Convenções do SIDRA

No SIDRA, "-" significa zero absoluto e "..." significa dado não disponível (município ainda não instalado).
Nos CSV, "-" foi convertido em **0** e "..." em **célula vazia**. Células vazias: Ipiranga do Norte e Itanhangá (2000–2004, antes da instalação);
Colniza, Nova Santa Helena, Rondolândia e Santa Rita do Trivelato (2000); Gaúcha do Norte (2002, sem informação na PAM).
Zeros: Apiacás (2014–2020) e Nova Monte Verde (2019–2020) não registraram área de milho.

### Observação sobre as tabelas 5457 e 839

Os totais da mesorregião nas duas tabelas coincidem em todos os anos, exceto em 2007 e 2009, em que a tabela 839 difere
(4,36 Mt e 5,16 Mt, contra 4,36 Mt e 5,81 Mt na tabela 5457). A análise principal usa a tabela 5457; a 839 serve apenas para estimar a participação da 2ª safra.

### Conferência com o artigo

Os scripts reproduzem exatamente os valores do artigo para a série regional (Tabela 3, τ de Mann-Kendall e declives de Sen),
para a lacuna entre municípios (39 municípios, CV = 7,2%, P90 = 6.159 kg ha⁻¹, lacuna de 1,03 Mt/ano, Tabela 4)
e para o Monte Carlo (Tabela 5 e correlações de Spearman).

**Exceção — I de Moran:** com os centroides deste pacote, obtém-se I = 0,178 (p = 0,020), e não 0,137 (p = 0,047).
O resultado é sensível à geometria usada para os centroides e ao número de vizinhos (k = 4: 0,21; k = 6: 0,12),
mas a conclusão (dependência espacial positiva, fraca e significativa com k = 5) se mantém.
Para reproduzir o valor do artigo, substitua as colunas de centroide de `municipios_norte_mt.csv`
pelos centroides calculados a partir da malha municipal do IBGE de 2023, ou atualize o valor no texto.

## Como citar

Autores. (2026). *Rendimento escondido no estande — conjunto de dados e códigos* [Conjunto de dados]. Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX

## Licença

Dados: CC BY 4.0. Código: MIT. Ver `LICENSE.md`.
