"""Perda de produção de milho por falhas de estande: cenário central e Monte Carlo.

Reproduz a Tabela 5 e a análise de sensibilidade (correlação de Spearman) do
artigo. Parâmetros de estande: Circuito Tecnológico - Etapa Milho 2017
(Borghi et al., 2018); produção e produtividade: PAM/IBGE, médias de 2016-2020.

Uso:  python scripts/02_monte_carlo_perda_estande.py   (a partir da raiz do pacote)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

N_ITER = 100_000
SEED = 2026

# Circuito Tecnológico 2017 (Borghi et al., 2018)
E = 57_636      # estande médio observado (plantas/ha)
N_F = 4_785     # plantas perdidas por falhas (plantas/ha)
N_M = 3_188     # plantas em espaçamentos curtos/duplas (plantas/ha)


def perda(d, s, fm, pm):
    """Equação 3: L = S*d + pm*fm."""
    return s * d + pm * fm


def main():
    pam = pd.read_csv(DATA / "pam_milho_norte_mt_2000_2020.csv")
    rec = pam[pam.ano.between(2016, 2020)].groupby("ano")[["producao_t", "area_colhida_ha"]].sum()
    p_obs = rec.producao_t.mean()                                        # t/ano
    y_bar = rec.producao_t.sum() / rec.area_colhida_ha.sum()             # t/ha

    # Lacuna entre municípios (resultado do script 01)
    mun = pd.read_csv(OUT / "municipios_media_2016_2020_area_min_5000ha.csv")
    g_reg = mun.lacuna_t.sum()

    d0 = N_F / (E + N_F)          # Equação 2
    fm = N_M / E

    # Cenário central
    l0 = perda(d0, 0.55, fm, 0.15)
    dp0 = p_obs * l0 / (1 - l0)   # Equação 4
    print(f"d = {d0:.4f}; f_m = {fm:.4f}")
    print(f"Cenário central: L = {l0 * 100:.2f}%; ΔP = {dp0 / 1e6:.2f} Mt/ano; "
          f"A_eq = {dp0 / y_bar / 1000:.0f} mil ha; razão ΔP/G_reg = {dp0 / g_reg:.2f}")

    # Monte Carlo (Tabela 2)
    rng = np.random.default_rng(SEED)
    d = rng.triangular(0.05, d0, 0.12, N_ITER)
    s = rng.uniform(0.3, 0.8, N_ITER)
    pm = rng.uniform(0.0, 0.3, N_ITER)
    L = perda(d, s, fm, pm)
    dP = p_obs * L / (1 - L)
    a_eq = dP / y_bar
    ratio = dP / g_reg

    pct = [5, 50, 95]
    tab = pd.DataFrame({
        "indicador": ["Perda relativa L (%)", "Produção perdida (Mt/ano)",
                      "Área equivalente (mil ha)", "Razão perda/lacuna entre municípios"],
        **{f"P{q}": [np.percentile(L * 100, q), np.percentile(dP / 1e6, q),
                     np.percentile(a_eq / 1000, q), np.percentile(ratio, q)] for q in pct},
        "cenario_central": [l0 * 100, dp0 / 1e6, dp0 / y_bar / 1000, dp0 / g_reg],
    })
    tab.round(3).to_csv(OUT / "tabela5_monte_carlo.csv", index=False)
    print("\nTabela 5")
    print(tab.round(2).to_string(index=False))

    print("\nCorrelação de Spearman entre parâmetro e perda simulada")
    for nome, v in [("S", s), ("d", d), ("p_m", pm)]:
        print(f"  {nome:4s} rho = {stats.spearmanr(v, L)[0]:.2f}")

    pd.DataFrame({"d": d, "S": s, "p_m": pm, "L": L}).iloc[:10_000].to_csv(
        OUT / "amostra_monte_carlo_10000.csv", index=False, float_format="%.6f")


if __name__ == "__main__":
    main()
