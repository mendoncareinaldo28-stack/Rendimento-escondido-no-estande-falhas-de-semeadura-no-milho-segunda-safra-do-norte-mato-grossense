"""Série regional, lacuna de produtividade entre municípios e I de Moran.

Reproduz a Tabela 3, a Tabela 4 e os resultados de tendência, lacuna e
dependência espacial do artigo "Rendimento escondido no estande: falhas de
semeadura no milho segunda safra do norte mato-grossense".

Uso:  python scripts/01_serie_lacuna_moran.py   (a partir da raiz do pacote)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

ANOS_MEDIA = range(2016, 2021)
AREA_MIN = 5000          # ha, área colhida média mínima
K_VIZINHOS = 5
N_PERM = 9999
SEED = 2026


def mann_kendall(x):
    """Teste de Mann-Kendall (sem correção de autocorrelação), com ajuste para empates."""
    x = np.asarray(x, float)
    n = len(x)
    s = sum(np.sign(x[j] - x[i]) for i in range(n - 1) for j in range(i + 1, n))
    _, counts = np.unique(x, return_counts=True)
    var_s = (n * (n - 1) * (2 * n + 5) - sum(t * (t - 1) * (2 * t + 5) for t in counts)) / 18
    z = (s - np.sign(s)) / np.sqrt(var_s) if s != 0 else 0.0
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    tau = s / (n * (n - 1) / 2)
    return tau, z, p


def sen_slope(x):
    x = np.asarray(x, float)
    n = len(x)
    return np.median([(x[j] - x[i]) / (j - i) for i in range(n - 1) for j in range(i + 1, n)])


def moran_knn(values, lon, lat, k=K_VIZINHOS, n_perm=N_PERM, seed=SEED):
    """I de Moran com matriz dos k vizinhos mais próximos padronizada na linha.

    As distâncias são calculadas em km por projeção equiretangular local.
    O p-valor é unilateral (pseudo p-valor por permutação, autocorrelação positiva).
    """
    y = np.asarray(values, float)
    lat0 = np.deg2rad(np.mean(lat))
    xy = np.c_[np.asarray(lon) * 111.32 * np.cos(lat0), np.asarray(lat) * 110.57]
    d = np.sqrt(((xy[:, None, :] - xy[None, :, :]) ** 2).sum(-1))
    np.fill_diagonal(d, np.inf)
    n = len(y)
    w = np.zeros((n, n))
    nn = np.argsort(d, axis=1)[:, :k]
    for i in range(n):
        w[i, nn[i]] = 1 / k

    def stat(v):
        z = v - v.mean()
        return (n / w.sum()) * (z @ w @ z) / (z @ z)

    i_obs = stat(y)
    rng = np.random.default_rng(seed)
    sims = np.array([stat(rng.permutation(y)) for _ in range(n_perm)])
    p = (np.sum(sims >= i_obs) + 1) / (n_perm + 1)
    return i_obs, p


def main():
    pam = pd.read_csv(DATA / "pam_milho_norte_mt_2000_2020.csv", dtype={"cod_ibge": str})
    mt = pd.read_csv(DATA / "pam_milho_mato_grosso_2000_2020.csv")
    mun = pd.read_csv(DATA / "municipios_norte_mt.csv", dtype={"cod_ibge": str})

    # ---------------- Série regional (Tabela 3, Figura 2a) ----------------
    reg = pam.groupby("ano")[["area_plantada_ha", "area_colhida_ha", "producao_t"]].sum()
    reg["produtividade_kg_ha"] = reg.producao_t / reg.area_colhida_ha * 1000
    reg["aproveitamento"] = reg.area_colhida_ha / reg.area_plantada_ha
    reg["participacao_mt_pct"] = reg.producao_t / mt.set_index("ano").producao_t * 100
    reg.round(4).to_csv(OUT / "serie_regional_norte_mt.csv")

    print("Tabela 3 - anos selecionados")
    sel = reg.loc[[2000, 2005, 2010, 2015, 2016, 2020]]
    print(pd.DataFrame({
        "area_mil_ha": (sel.area_colhida_ha / 1000).round(1),
        "producao_Mt": (sel.producao_t / 1e6).round(2),
        "produtividade": sel.produtividade_kg_ha.round(0),
        "part_MT_%": sel.participacao_mt_pct.round(1),
        "aproveitamento": sel.aproveitamento.round(3),
    }).to_string())

    print("\nMann-Kendall e declive de Sen (2000-2020)")
    for col, lab in [("area_colhida_ha", "área"), ("producao_t", "produção"),
                     ("produtividade_kg_ha", "produtividade")]:
        tau, z, p = mann_kendall(reg[col])
        print(f"  {lab:14s} tau={tau:.3f}  p={p:.2e}  Sen={sen_slope(reg[col]):,.1f} /ano")

    y15_17 = reg.loc[[2015, 2017], "produtividade_kg_ha"].mean()
    print(f"\n2016: queda de produtividade vs média 2015/2017 = "
          f"{(1 - reg.loc[2016, 'produtividade_kg_ha'] / y15_17) * 100:.1f}%; "
          f"área não colhida = {reg.loc[2016, 'area_plantada_ha'] - reg.loc[2016, 'area_colhida_ha']:,.0f} ha")

    # ---------------- Lacuna entre municípios (Tabela 4) ----------------
    rec = pam[pam.ano.isin(ANOS_MEDIA)]
    m = rec.groupby(["cod_ibge", "municipio", "microrregiao"])[["area_colhida_ha", "producao_t"]].mean().reset_index()
    m["produtividade_kg_ha"] = m.producao_t / m.area_colhida_ha * 1000
    m = m[m.area_colhida_ha >= AREA_MIN].copy()
    p90 = np.percentile(m.produtividade_kg_ha, 90)
    m["lacuna_kg_ha"] = np.maximum(0, p90 - m.produtividade_kg_ha)
    m["lacuna_t"] = m.lacuna_kg_ha * m.area_colhida_ha / 1000
    m = m.merge(mun[["cod_ibge", "lon_centroide", "lat_centroide"]], on="cod_ibge")
    m.sort_values("producao_t", ascending=False).round(2).to_csv(
        OUT / "municipios_media_2016_2020_area_min_5000ha.csv", index=False)

    area_meso = rec.groupby("ano").area_colhida_ha.sum().mean()
    g_reg = m.lacuna_t.sum()
    print(f"\nMunicípios com área média >= {AREA_MIN} ha: {len(m)} "
          f"({m.area_colhida_ha.sum() / area_meso * 100:.1f}% da área colhida)")
    print(f"Produtividade média municipal = {m.produtividade_kg_ha.mean():,.0f} kg/ha; "
          f"CV = {m.produtividade_kg_ha.std(ddof=1) / m.produtividade_kg_ha.mean() * 100:.1f}%")
    lo, hi = m.loc[m.produtividade_kg_ha.idxmin()], m.loc[m.produtividade_kg_ha.idxmax()]
    print(f"Mínimo: {lo.municipio} {lo.produtividade_kg_ha:,.0f}; máximo: {hi.municipio} {hi.produtividade_kg_ha:,.0f}")
    print(f"Média ponderada pela área = {m.producao_t.sum() / m.area_colhida_ha.sum() * 1000:,.0f} kg/ha")
    print(f"P90 = {p90:,.0f} kg/ha; lacuna regional = {g_reg / 1e6:.2f} Mt/ano "
          f"({g_reg / (m.producao_t.sum() + g_reg) * 100:.1f}% da produção atingível)")
    top = m.nlargest(10, "producao_t")
    print(f"Dez maiores: {top.producao_t.sum() / m.producao_t.sum() * 100:.0f}% da produção")
    print(top[["municipio", "microrregiao", "area_colhida_ha", "producao_t",
               "produtividade_kg_ha", "lacuna_kg_ha"]].round(0).to_string(index=False))

    # ---------------- I de Moran ----------------
    i_obs, p = moran_knn(m.produtividade_kg_ha.values, m.lon_centroide.values, m.lat_centroide.values)
    print(f"\nI de Moran (k={K_VIZINHOS}, {N_PERM} permutações) = {i_obs:.3f}; p = {p:.3f}")

    # Valores de entrada do modelo de perda
    pobs = rec.groupby("ano").producao_t.sum().mean()
    ybar = rec.groupby("ano").producao_t.sum().sum() / rec.groupby("ano").area_colhida_ha.sum().sum() * 1000
    print(f"\nP_obs (média 2016-2020) = {pobs / 1e6:.2f} Mt/ano; Ybar = {ybar:,.0f} kg/ha")


if __name__ == "__main__":
    main()
